//
//  ViewController.swift
//  SmartFinancePR
//
//  Created by Никита Куприн on 15.12.2023.
//

import UIKit
import CoreData
import Foundation

enum Constants {
    static let initialCurrencyValues = 0.0
    
    static let userNameLabelTop:CGFloat = 20
    static let userNameLabelLeading:CGFloat = 20
    static let userNameLabelTrailing:CGFloat = -20
    
    static let userFinanceLabelTop:CGFloat = 20
    static let userFinanceLabelLeading:CGFloat = 20
    static let userFinanceLabelTrailing:CGFloat = -20
    
    static let exchangeRateLabelTop:CGFloat = 20
    static let exchangeRateLabelLeading:CGFloat = 20
    static let exchangeRateLabelTrailing:CGFloat = -20
    
    static let incomeButtonTop:CGFloat = 30
    static let incomeButtonLeading:CGFloat = 20
    static let incomeButtonTrailing:CGFloat = -20
    static let incomeButtonHeight:CGFloat = 50
    
    static let expenseButtonTop:CGFloat = 20
    static let expenseButtonLeading:CGFloat = 20
    static let expenseButtonTrailing:CGFloat = -20
    static let expenseButtonHeight:CGFloat = 50
    
    static let statisticsButtonTop:CGFloat = 20
    static let statisticsButtonLeading:CGFloat = 20
    static let statisticsButtonTrailing:CGFloat = -20
    static let statisticsButtonHeight:CGFloat = 50
    
    static let apiKey = "15fc14445a1d5e5252f97e373e5c4556"
}

class MainViewController: UIViewController {
    
    var user: User!
    var RubUSD = Constants.initialCurrencyValues
    var RubEUR = Constants.initialCurrencyValues
    
    private let userNameLabel = UILabel()
    private let userFinanceLabel = UILabel()
    private let exchangeRateLabel = UILabel()
    private let incomeButton = UIButton(type: .system)
    private let expenseButton = UIButton(type: .system)
    private let statisticsButton = UIButton(type: .system)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        user = User(name: UserDefaults.standard.string(forKey: "userName") ?? "?", balance: fetchUserBalance(), currency: "RUB")
        
        setupUI()
        fetchExchangeRates()
        sleep(1)
        updateUIWithUserData()
        
        NotificationCenter.default.addObserver(self, selector: #selector(updateUIWithUserData), name: .didUpdateUserName, object: nil)
    }
    
    deinit {
        // Отписка от уведомлений при уничтожении контроллера
        NotificationCenter.default.removeObserver(self)
    }
    
    private func setupUI() {
        // Настройка интерфейса
        view.backgroundColor = .systemBackground
        
        // Настройка и добавление лейблов
        setupLabel(userNameLabel, text: "Имя пользователя")
        setupLabel(userFinanceLabel, text: "Бюджет: ")
        setupLabel(exchangeRateLabel, text: "USD: \(RubUSD), EUR: \(RubEUR)")
        
        // Настройка и добавление кнопок
        setupButton(incomeButton, title: "Доход", action: #selector(incomeButtonTapped))
        setupButton(expenseButton, title: "Расход", action: #selector(expenseButtonTapped))
        setupButton(statisticsButton, title: "Статистика", action: #selector(statisticsButtonTapped))
        
        // Расположение элементов на экране
        layoutUIComponents()
    }
    
    private func setupLabel(_ label: UILabel, text: String) {
        label.text = text
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(label)
    }
    
    private func setupButton(_ button: UIButton, title: String, action: Selector) {
        button.backgroundColor = .black
        button.setTitle(title, for: .normal)
        button.addTarget(self, action: action, for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(button)
    }
    
    private func layoutUIComponents() {
        // Констрейнты для userNameLabel
        NSLayoutConstraint.activate([
            userNameLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: Constants.userNameLabelTop),
            userNameLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: Constants.userNameLabelLeading),
            userNameLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: Constants.userNameLabelTrailing)
        ])
        
        // Констрейнты для userFinanceLabel
        NSLayoutConstraint.activate([
            userFinanceLabel.topAnchor.constraint(equalTo: userNameLabel.bottomAnchor, constant: Constants.userFinanceLabelTop),
            userFinanceLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: Constants.userFinanceLabelLeading),
            userFinanceLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: Constants.userFinanceLabelTrailing)
        ])
        
        // Констрейнты для exchangeRateLabel
        NSLayoutConstraint.activate([
            exchangeRateLabel.topAnchor.constraint(equalTo: userFinanceLabel.bottomAnchor, constant: Constants.exchangeRateLabelTop),
            exchangeRateLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: Constants.exchangeRateLabelLeading),
            exchangeRateLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: Constants.exchangeRateLabelTrailing)
        ])
        
        // Констрейнты для incomeButton
        NSLayoutConstraint.activate([
            incomeButton.topAnchor.constraint(equalTo: exchangeRateLabel.bottomAnchor, constant: Constants.incomeButtonTop),
            incomeButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: Constants.incomeButtonLeading),
            incomeButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: Constants.incomeButtonTrailing),
            incomeButton.heightAnchor.constraint(equalToConstant: Constants.incomeButtonHeight)
        ])
        
        // Констрейнты для expenseButton
        NSLayoutConstraint.activate([
            expenseButton.topAnchor.constraint(equalTo: incomeButton.bottomAnchor, constant: Constants.expenseButtonTop),
            expenseButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: Constants.expenseButtonLeading),
            expenseButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: Constants.expenseButtonTrailing),
            expenseButton.heightAnchor.constraint(equalToConstant: Constants.expenseButtonHeight)
        ])
        
        // Констрейнты для statisticsButton
        NSLayoutConstraint.activate([
            statisticsButton.topAnchor.constraint(equalTo: expenseButton.bottomAnchor, constant: Constants.statisticsButtonTop),
            statisticsButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: Constants.statisticsButtonLeading),
            statisticsButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: Constants.statisticsButtonTrailing),
            statisticsButton.heightAnchor.constraint(equalToConstant: Constants.statisticsButtonHeight)
        ])
    }
    
    @objc func updateUIWithUserData() {
        user.name = UserDefaults.standard.string(forKey: "userName") ?? "?"
        user.balance = fetchUserBalance()
        userNameLabel.text = "Здравствуйте, \(user.name)"
        userFinanceLabel.text = "Баланс: \(user.balance) \(user.currency)"
        
        let numberFormatter = NumberFormatter()
        numberFormatter.numberStyle = .decimal
        
        // Задаем количество знаков после запятой
        numberFormatter.maximumFractionDigits = 2
        var rubUSDText = ""
        if let rubUSDTextFormat = numberFormatter.string(from: NSNumber(value: RubUSD)) {
            // Устанавливаем отформатированное число в UILabel
            rubUSDText = rubUSDTextFormat
        }
        if let rubEURTextFormat = numberFormatter.string(from: NSNumber(value: RubEUR)) {
            // Устанавливаем отформатированное число в UILabel
            exchangeRateLabel.text = "USD: \(rubUSDText) EUR: \(rubEURTextFormat)"
        }
        
        fetchExchangeRates()
    }

    // Обработчики нажатий кнопок
    @objc private func statisticsButtonTapped() {
        let statisticsVC = StatisticsViewController()
        navigationController?.pushViewController(statisticsVC, animated: true)
    }
    
    @objc private func incomeButtonTapped() {
        presentEntryViewController(forType: "Income")
    }

    @objc private func expenseButtonTapped() {
        presentEntryViewController(forType: "Expense")
    }

    private func presentEntryViewController(forType type: String) {
        if type == "Income" {
            let entryVC = EntryIncomeViewController()
            entryVC.modalPresentationStyle = .formSheet
            present(entryVC, animated: true)
        } else {
            let entryVC = EntryExpenseViewController()
            entryVC.modalPresentationStyle = .formSheet
            present(entryVC, animated: true)
        }
    }
    
    func fetchUserBalance() -> Double {
        return UserDefaults.standard.double(forKey: "userBalance")
    }
    
    func fetchExchangeRates() {
        // Создаем URL на основе API endpoint
        if let url = URL(string: "http://data.fixer.io/api/latest?access_key=\(Constants.apiKey)") {
            
            // Создаем URLSession
            let session = URLSession.shared
            
            // Создаем запрос
            let task = session.dataTask(with: url) { (data, response, error) in
                if let error = error {
                    print("Ошибка: \(error)")
                    return
                }
                
                // Проверяем, получили ли мы данные
                guard let data = data else {
                    print("Данные не получены")
                    return
                }
                
                // Попытка разбора JSON
                do {
                    if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] {
                        if let rates = json["rates"] as? [String: Double] {
                            if let usdRate = rates["USD"], let rubRate = rates["RUB"] {
                                self.RubEUR = Double(rubRate)
                                self.RubUSD = self.RubEUR / Double(usdRate)
                            } else {
                                print("Курсы USD и RUB не найдены")
                            }
                        } else {
                            print("Курсы валют не найдены")
                        }
                    }
                } catch {
                    print("Ошибка при разборе JSON: \(error)")
                }
            }
            task.resume()
        } else {
            print("Ошибка в создании URL")
        }
    }
}

extension Notification.Name {
    static let didUpdateUserName = Notification.Name("didUpdateUserName")
}
