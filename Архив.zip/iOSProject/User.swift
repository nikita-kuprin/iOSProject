//
//  User.swift
//  SmartFinancePR
//
//  Created by Никита Куприн on 18.12.2023.
//

import Foundation

class User {
    var name: String
    var balance: Double
    var currency: String

    init(name: String, balance: Double, currency: String = "RUB") {
        self.name = name
        self.balance = balance
        self.currency = currency
    }

    func addIncome(_ amount: Double) {
        balance += amount
    }

    func addExpense(_ amount: Double) {
        balance -= amount
    }
}
