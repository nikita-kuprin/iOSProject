//
//  LineGraphView.swift
//  SmartFinancePR
//
//  Created by Никита Куприн on 19.12.2023.
//

import Foundation
import UIKit

class LineGraphView: UIView {
    var dataPoints: [CGPoint] = []

    override func draw(_ rect: CGRect) {
        guard let context = UIGraphicsGetCurrentContext() else { return }

        context.setStrokeColor(UIColor.blue.cgColor)
        context.setLineWidth(2)

        if !dataPoints.isEmpty {
            context.move(to: dataPoints[0])
        }

        for point in dataPoints {
            context.addLine(to: point)
        }

        context.strokePath()
    }

    func setDataPoints(points: [CGPoint]) {
        dataPoints = points
        self.setNeedsDisplay()
    }
}
