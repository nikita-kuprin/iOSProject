//
//  TransactionManager.swift
//  SmartFinancePR
//
//  Created by Никита Куприн on 19.12.2023.
//

import Foundation
import CoreData
import UIKit

class TransactionManager {

    static let shared = TransactionManager()
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

    func addTransaction(amount: Double, type: String, category: String) {
        let newTransaction = Transaction(context: context)
        newTransaction.amount = amount
        newTransaction.type = type
        newTransaction.date = Date()
        newTransaction.category = category
        
        var incomeStatus = true
        
        if (type == "Income") {
            incomeStatus = true
        } else {
            incomeStatus = false
        }
        
        updateBalance(amount: amount, isIncome: incomeStatus)
        
        do {
            try context.save()
        } catch {
            print("Ошибка при сохранении транзакции: \(error)")
        }
        
        NotificationCenter.default.post(name: .didUpdateUserName, object: nil)
    }

    func updateBalance(amount: Double, isIncome: Bool) {
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        
        var currentUserBalance = UserDefaults.standard.double(forKey: "userBalance")
        currentUserBalance += isIncome ? amount : -amount
        UserDefaults.standard.set(currentUserBalance, forKey: "userBalance")
        do {
            try context.save()
        } catch {
            print("Ошибка при обновлении баланса: \(error)")
        }
    }
}
