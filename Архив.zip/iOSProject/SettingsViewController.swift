//
//  SettingsViewController.swift
//  SmartFinancePR
//
//  Created by Никита Куприн on 18.12.2023.
//

import Foundation
import UIKit

class SettingsViewController: UIViewController, UIImagePickerControllerDelegate & UINavigationControllerDelegate {
    
    private let userNameTextField = UITextField()
    private let saveButton = UIButton(type: .system)
    private let avatarImageView = UIImageView()
    private let changeAvatarButton = UIButton(type: .system)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        
        setupUserNameTextField()
        setupAvatarImageView()
        setupChangeAvatarButton()
        setupSaveButton()
    }
    
    private func setupAvatarImageView() {
        avatarImageView.contentMode = .scaleAspectFill
        avatarImageView.backgroundColor = .lightGray
        avatarImageView.layer.cornerRadius = 50
        avatarImageView.clipsToBounds = true
        view.addSubview(avatarImageView)
        avatarImageView.translatesAutoresizingMaskIntoConstraints = false
        
        if let savedImage = loadImageFromUserDefaults() {
            avatarImageView.image = savedImage
        }
        
        NSLayoutConstraint.activate([
            avatarImageView.topAnchor.constraint(equalTo: userNameTextField.bottomAnchor, constant: 20),
            avatarImageView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            avatarImageView.widthAnchor.constraint(equalToConstant: 100),
            avatarImageView.heightAnchor.constraint(equalToConstant: 100)
        ])
    }
    
    private func setupChangeAvatarButton() {
        changeAvatarButton.setTitle("Изменить аватар", for: .normal)
        changeAvatarButton.addTarget(self, action: #selector(changeAvatarButtonTapped), for: .touchUpInside)
        view.addSubview(changeAvatarButton)
        changeAvatarButton.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            changeAvatarButton.topAnchor.constraint(equalTo: avatarImageView.bottomAnchor, constant: 10),
            changeAvatarButton.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])
    }
    
    @objc private func changeAvatarButtonTapped() {
        let imagePickerController = UIImagePickerController()
        imagePickerController.sourceType = .photoLibrary
        imagePickerController.delegate = self
        present(imagePickerController, animated: true)
        
    }
    
    private func setupUserNameTextField() {
        userNameTextField.placeholder = "Введите имя пользователя"
        userNameTextField.borderStyle = .roundedRect
        view.addSubview(userNameTextField)
        userNameTextField.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            userNameTextField.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            userNameTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            userNameTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20)
        ])
    }
    
    private func setupSaveButton() {
        view.addSubview(saveButton)
        saveButton.setTitle("Сохранить", for: .normal)
        saveButton.addTarget(self, action: #selector(saveSettings), for: .touchUpInside)
        saveButton.translatesAutoresizingMaskIntoConstraints = false
        saveButton.backgroundColor = .green
        NSLayoutConstraint.activate([
            saveButton.topAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.topAnchor, constant: 500),
            saveButton.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 20),
            saveButton.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -20),
            saveButton.heightAnchor.constraint(equalToConstant: 50)
        ])
    }
    
    @objc private func saveSettings() {
        let username = userNameTextField.text ?? "" // Получаем текст из textField или пустую строку, если textField пустой
        UserDefaults.standard.set(username, forKey: "userName") // Сохраняем имя пользователя по ключу "userName"
        UserDefaults.standard.synchronize() // Синхронизируем UserDefaults
        
        // Оповещаем о том, что имя пользователя было изменено
        NotificationCenter.default.post(name: .didUpdateUserName, object: nil)
        
        
        // Показываем подтверждение пользователю, что его имя было сохранено
        let alert = UIAlertController(title: "Успех", message: "Имя пользователя сохранено", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
    
    func loadImageFromUserDefaults() -> UIImage? {
        if let imageData = UserDefaults.standard.data(forKey: "userAvatar") {
            return UIImage(data: imageData)
        }
        return nil
    }
}

extension SettingsViewController {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let selectedImage = info[.originalImage] as? UIImage {
            // Отобразить в UIImageView
            avatarImageView.image = selectedImage

            // Сохраняем изображение в UserDefaults
            saveImageToUserDefaults(image: selectedImage)

            dismiss(animated: true)
        }
    }

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true)
    }

    func saveImageToUserDefaults(image: UIImage) {
        if let imageData = image.jpegData(compressionQuality: 1) ?? image.pngData() {
            UserDefaults.standard.set(imageData, forKey: "userAvatar")
            // Синхронизация UserDefaults не всегда необходима, но можно выполнить для немедленного сохранения
            UserDefaults.standard.synchronize()
        }
    }
}
