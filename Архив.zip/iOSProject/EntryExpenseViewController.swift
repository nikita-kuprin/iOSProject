//
//  EntryViewController.swift
//  SmartFinancePR
//
//  Created by Никита Куприн on 18.12.2023.
//

import Foundation
import UIKit

class EntryExpenseViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {

    var categoryPicker = UIPickerView()
    var amountTextField = UITextField()
    var datePicker = UIDatePicker()
    let submitButton = UIButton(type: .system)
    var categories = ["Продукты", "Одежда", "Техника", "Долги","Другое"]

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .cyan
        setupAmountTextField()
        setupCategoryPicker()
        setupDatePicker()
        setupSubmitButton()
    }

    func setupAmountTextField() {
        self.view.addSubview(amountTextField)
        amountTextField.translatesAutoresizingMaskIntoConstraints = false
        amountTextField.placeholder = "Введите сумму"
        amountTextField.keyboardType = .decimalPad
        NSLayoutConstraint.activate([
            amountTextField.topAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.topAnchor, constant: 60),
            amountTextField.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 20),
            amountTextField.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -20)
        ])
    }

    func setupCategoryPicker() {
        self.view.addSubview(categoryPicker)
        categoryPicker.translatesAutoresizingMaskIntoConstraints = false
        categoryPicker.dataSource = self
        categoryPicker.delegate = self
        NSLayoutConstraint.activate([
            categoryPicker.topAnchor.constraint(equalTo: self.amountTextField.bottomAnchor, constant: 30),
            categoryPicker.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 20),
            categoryPicker.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -20)
        ])
    }

    func setupDatePicker() {
        self.view.addSubview(datePicker)
        datePicker.translatesAutoresizingMaskIntoConstraints = false
        datePicker.datePickerMode = .date
        NSLayoutConstraint.activate([
            datePicker.topAnchor.constraint(equalTo: self.categoryPicker.bottomAnchor, constant: 30),
            datePicker.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 20),
            datePicker.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -20)
        ])
    }

    func setupSubmitButton() {
        self.view.addSubview(submitButton)
        submitButton.translatesAutoresizingMaskIntoConstraints = false
        submitButton.backgroundColor = .blue
        submitButton.setTitle("Подтвердить", for: .normal)
        
        submitButton.addTarget(self, action: #selector(submitButtonTapped), for: .touchUpInside)
        // Установите констрейнты для кнопки
        NSLayoutConstraint.activate([
            submitButton.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 500),
            submitButton.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 20),
            submitButton.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -20),
            submitButton.heightAnchor.constraint(equalToConstant: 40)
        ])
    }

    // DataSource и Delegate методы для UIPickerView
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return categories.count
    }

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return categories[row]
    }

    @objc func submitButtonTapped() {
        guard let amountText = amountTextField.text, let amount = Double(amountText) else {
            print("Ошибка: невозможно преобразовать введенную сумму в число.")
            return
        }
        
        let selectedIndex = categoryPicker.selectedRow(inComponent: 0)
        let selectedCategory = categories[selectedIndex] // Предполагаем, что у вас есть массив `categories`
        
        TransactionManager.shared.addTransaction(amount: amount, type: "Expense", category: selectedCategory)
        // Оповещаем о том, что имя пользователя было изменено
        NotificationCenter.default.post(name: .didUpdateUserName, object: nil)
        
        // Закрытие этого контроллера
        dismiss(animated: true, completion: nil)
    }
}
