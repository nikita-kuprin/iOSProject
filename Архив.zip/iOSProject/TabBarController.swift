//
//  TabBarController.swift
//  SmartFinancePR
//
//  Created by Никита Куприн on 18.12.2023.
//

import Foundation
import UIKit

class TabBarController: UITabBarController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let mainViewController = MainViewController()
        mainViewController.title = "Главная"
        let mainNavController = UINavigationController(rootViewController: mainViewController)
        mainViewController.tabBarItem = UITabBarItem(title: "Главная", image: nil, tag: 0)
        
        let settingsViewController = SettingsViewController()
        settingsViewController.title = "Настройки"
        let settingsNavController = UINavigationController(rootViewController: settingsViewController)
        
        settingsViewController.tabBarItem = UITabBarItem(title: "Настройки", image: nil, tag: 1)
        
        self.viewControllers = [mainNavController, settingsNavController]
    }
}
