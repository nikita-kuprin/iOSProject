//
//  StatisticsViewController.swift
//  SmartFinancePR
//
//  Created by Никита Куприн on 19.12.2023.
//

import Foundation
import UIKit
import Charts
import CoreData

class StatisticsViewController: UIViewController {
    
    var lineGraphView: LineGraphView!

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .gray

        setupLineGraphView()
        loadDataForLineGraph()
    }

    private func setupLineGraphView() {
        lineGraphView = LineGraphView()
        lineGraphView.frame = CGRect(x: 20, y: 100, width: view.frame.size.width - 40, height: 300)
        view.addSubview(lineGraphView)
        lineGraphView.translatesAutoresizingMaskIntoConstraints = false
    }

    private func loadDataForLineGraph() {
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        let fetchRequest: NSFetchRequest<Transaction> = Transaction.fetchRequest()

        do {
            let transactions = try context.fetch(fetchRequest)
            print(transactions)
            var sampleData: [CGPoint] = []
            for (index, transaction) in transactions.enumerated() {
                // Преобразование даты транзакции в координату X (например, порядковый номер транзакции)
                let xValue = CGFloat(index)

                // Использование суммы транзакции как координаты Y
                let yValue = CGFloat(transaction.amount)
                
                sampleData.append(CGPoint(x: xValue, y: yValue))
            }

            lineGraphView.setDataPoints(points: sampleData)
        } catch let error as NSError {
            print("Ошибка при извлечении транзакций: \(error), \(error.userInfo)")
        }
    }

}
